# Contributing
Contributing towards activities can be done by submitting pull requests. All functionalies should provide testing material and include docstrings. Do not forget to add potential dependencies to `setup.py`.
